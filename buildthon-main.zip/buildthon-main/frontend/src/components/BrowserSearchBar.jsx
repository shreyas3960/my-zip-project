import { useState, useRef, useEffect } from 'react';
import { Search, Mic, Send } from 'lucide-react';
import { useGoogleSuggestions } from '../hooks/useGoogleSuggestions';

export default function BrowserSearchBar({ onSearch, onNavigate }) {
  const [query, setQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const { suggestions } = useGoogleSuggestions(query, showSuggestions);
  const inputRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    if (query.includes('.') || query.startsWith('http')) {
      const url = query.startsWith('http') ? query : `https://${query}`;
      onNavigate(url);
    } else {
      onSearch(query);
    }
    setShowSuggestions(false);
  };

  const handleSuggestionClick = (suggestion) => {
    setQuery(suggestion);
    setShowSuggestions(false);
    onSearch(suggestion);
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (inputRef.current && !inputRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative w-full max-w-3xl mx-auto" ref={inputRef}>
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex items-center bg-white/5 border border-white/10 rounded-lg overflow-hidden focus-within:border-white/30 transition-colors">
          <Search className="w-4 h-4 ml-4 text-white/50" />
          <input
            data-testid="browser-search-input"
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setShowSuggestions(true);
            }}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Search or enter URL"
            className="flex-1 bg-transparent px-4 py-3 text-white placeholder:text-white/40 outline-none text-sm"
          />
          <button
            type="button"
            data-testid="voice-search-btn"
            className="p-3 text-white/50 hover:text-white transition-colors"
          >
            <Mic className="w-4 h-4" />
          </button>
          <button
            type="submit"
            data-testid="search-submit-btn"
            className="p-3 text-white/50 hover:text-white transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>

      {/* Suggestions Dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div
          data-testid="search-suggestions"
          className="absolute top-full mt-1 w-full bg-black border border-white/10 rounded-lg overflow-hidden z-50"
        >
          {suggestions.slice(0, 8).map((suggestion, index) => (
            <button
              key={index}
              data-testid={`suggestion-${index}`}
              onClick={() => handleSuggestionClick(suggestion)}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-left text-white/80 hover:bg-white/5 transition-colors text-sm"
            >
              <Search className="w-3.5 h-3.5 text-white/40" />
              <span>{suggestion}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
