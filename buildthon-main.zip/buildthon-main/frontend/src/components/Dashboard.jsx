import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useSession } from '../hooks/useSession';
import { useDriftDetection } from '../hooks/useDriftDetection';
import ControlPanel from './ControlPanel';
import BrowserShell from './BrowserShell';
import FocusSession from './FocusSession';
import ClipsList from './ClipsList';
import NotesList from './NotesList';
import TasksList from './TasksList';
import SearchView from './SearchView';
import RightSideNudge from './RightSideNudge';
import { LogOut } from 'lucide-react';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [activeView, setActiveView] = useState('browser');
  const { currentSession } = useSession();
  const [pageContent, setPageContent] = useState('');
  const { isDrifting, missingKeywords, resetDrift } = useDriftDetection(
    currentSession,
    pageContent
  );

  const handleSnooze = () => {
    resetDrift();
    setTimeout(() => {
      // Re-enable after 5 minutes (simplified for demo)
    }, 5 * 60 * 1000);
  };

  const handleReturn = () => {
    resetDrift();
    setActiveView('focus');
  };

  const renderView = () => {
    switch (activeView) {
      case 'browser':
        return <BrowserShell />;
      case 'focus':
        return <FocusSession />;
      case 'clips':
        return <ClipsList />;
      case 'search':
        return <SearchView />;
      case 'tasks':
        return <TasksList />;
      case 'reader':
      case 'summarize':
      case 'research':
      case 'activity':
      case 'workspace':
      case 'settings':
      case 'library':
      case 'explore':
      case 'projects':
        return (
          <div className="flex items-center justify-center h-full text-white/60">
            <div className="text-center">
              <h2 className="text-xl font-semibold mb-2 capitalize">{activeView}</h2>
              <p className="text-sm mb-4">This feature is coming soon!</p>
              <button
                onClick={() => setActiveView('browser')}
                className="px-4 py-2 bg-white text-black rounded-lg text-sm hover:bg-white/90 transition-colors"
              >
                Back to Browser
              </button>
            </div>
          </div>
        );
      default:
        return <BrowserShell />;
    }
  };

  return (
    <div className="h-screen flex flex-col bg-black text-white">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10">
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium">DeepBrowser</span>
          <span className="text-xs text-white/40">v1.0</span>
        </div>
        {user && (
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              {user.picture && (
                <img
                  src={user.picture}
                  alt={user.name}
                  className="w-6 h-6 rounded-full"
                />
              )}
              <span className="text-sm text-white/70">{user.name}</span>
            </div>
            <button
              data-testid="logout-btn"
              onClick={logout}
              className="p-2 text-white/50 hover:text-white transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <div className="w-64 border-r border-white/10">
          <ControlPanel
            activeView={activeView}
            setActiveView={setActiveView}
            onNewTab={() => setActiveView('browser')}
          />
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden">
          {renderView()}
        </div>
      </div>

      {/* Drift Nudge */}
      {isDrifting && currentSession && (
        <RightSideNudge
          missingKeywords={missingKeywords}
          onReturn={handleReturn}
          onSnooze={handleSnooze}
          onIgnore={resetDrift}
        />
      )}
    </div>
  );
}
