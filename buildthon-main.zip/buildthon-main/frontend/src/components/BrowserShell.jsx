import { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, RefreshCw, X, Menu } from 'lucide-react';
import BrowserSearchBar from './BrowserSearchBar';
import BrowserPanel from './BrowserPanel';
import { useAuth } from '../hooks/useAuth';
import axios from 'axios';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function BrowserShell() {
  const { user } = useAuth();
  const [currentUrl, setCurrentUrl] = useState('');
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [iframeKey, setIframeKey] = useState(0);
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  const navigate = async (url) => {
    // Ensure URL has protocol
    let finalUrl = url;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      finalUrl = `https://${url}`;
    }

    setCurrentUrl(finalUrl);
    setIframeKey(prev => prev + 1);

    // Add to history
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(finalUrl);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    // Save to browsing history if user is logged in
    if (user) {
      try {
        await axios.post(
          `${API}/history`,
          {
            url: finalUrl,
            title: new URL(finalUrl).hostname
          },
          { withCredentials: true }
        );
      } catch (error) {
        console.error('Failed to save history:', error);
      }
    }
  };

  const handleSearch = (query) => {
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    navigate(searchUrl);
  };

  const goBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setCurrentUrl(history[historyIndex - 1]);
      setIframeKey(prev => prev + 1);
    }
  };

  const goForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setCurrentUrl(history[historyIndex + 1]);
      setIframeKey(prev => prev + 1);
    }
  };

  const reload = () => {
    setIframeKey(prev => prev + 1);
  };

  const closeTab = () => {
    setCurrentUrl('');
    setIframeKey(prev => prev + 1);
  };

  return (
    <div className="h-full flex flex-col bg-black">
      {/* Navigation Bar */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
        <button
          data-testid="browser-back-btn"
          onClick={goBack}
          disabled={historyIndex <= 0}
          className="p-2 text-white/50 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button
          data-testid="browser-forward-btn"
          onClick={goForward}
          disabled={historyIndex >= history.length - 1}
          className="p-2 text-white/50 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
        <button
          data-testid="browser-reload-btn"
          onClick={reload}
          className="p-2 text-white/50 hover:text-white transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
        </button>

        <div className="flex-1 mx-4">
          <BrowserSearchBar onSearch={handleSearch} onNavigate={navigate} />
        </div>

        {currentUrl && (
          <button
            data-testid="browser-close-tab-btn"
            onClick={closeTab}
            className="p-2 text-white/50 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        <button
          data-testid="browser-panel-toggle-btn"
          onClick={() => setIsPanelOpen(!isPanelOpen)}
          className="p-2 text-white/50 hover:text-white transition-colors"
        >
          <Menu className="w-4 h-4" />
        </button>
      </div>

      {/* Browser Content */}
      <div className="flex-1 relative">
        {currentUrl ? (
          <iframe
            key={iframeKey}
            src={currentUrl}
            data-testid="browser-iframe"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            className="w-full h-full border-0"
            title="Browser Content"
          />
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center px-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-light mb-4 tracking-tight">
              What's on your mind today?
            </h1>
            <p className="text-white/60 text-base md:text-lg mb-8">
              Browse, research, and explore with AI assistance
            </p>
            <div className="w-full max-w-2xl">
              <BrowserSearchBar onSearch={handleSearch} onNavigate={navigate} />
            </div>
            <div className="flex gap-3 mt-8">
              <button
                data-testid="search-web-btn"
                onClick={() => handleSearch('latest news')}
                className="px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm transition-colors"
              >
                Search the web
              </button>
              <button
                data-testid="browse-privately-btn"
                className="px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm transition-colors"
              >
                Browse privately
              </button>
              <button
                data-testid="ai-research-btn"
                className="px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm transition-colors"
              >
                AI Research
              </button>
              <button
                data-testid="take-notes-btn"
                className="px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm transition-colors"
              >
                Take notes
              </button>
            </div>
            <div className="mt-12 text-xs text-white/40">
              Privacy-first browsing · No tracking · Open source
            </div>
          </div>
        )}

        {/* Right Side Panel */}
        {isPanelOpen && (
          <>
            <div
              className="absolute inset-0 bg-black/50 z-40"
              onClick={() => setIsPanelOpen(false)}
            />
            <div className="absolute top-0 right-0 h-full w-full md:w-[400px] bg-black border-l border-white/10 z-50 slide-in-right">
              <BrowserPanel onClose={() => setIsPanelOpen(false)} />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
